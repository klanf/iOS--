
import Foundation

/**
A demo method

- parameter input: An Int number

- returns: The string represents the input number
*/
func method(input: Int) -> String {
    return String(input)
}

struct Person {
    /// name of the person
    var name: String
}
