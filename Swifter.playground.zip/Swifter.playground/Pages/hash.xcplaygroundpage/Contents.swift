
import Foundation

let num = 19
print(num.hashValue) // 19
